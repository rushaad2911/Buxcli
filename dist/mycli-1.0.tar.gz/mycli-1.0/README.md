# A simple CLI tool for project setup automation made to make me look cool.
